<?php 
    defined('BASEPATH') OR exit('No direct script access allowed');

    class Categoria extends CI_Model{
        
    }