<?php
class SubcategoriasController extends CI_Controller{
  
    function index(){
        /*carrega a view */
        $this->template->load('layout', 'teste');
    }

    
}
