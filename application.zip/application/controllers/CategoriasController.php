<?php
class CategoriasController extends CI_Controller{
  
    function index(){
        /*carrega a view */
        $this->template->load('layout', 'teste');
    }

    
}
